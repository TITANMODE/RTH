chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.create({ url: atob("aHR0cHM6Ly93d3cucm9ibG94LmNvbS9nYW1lLXBhc3MvMjE4NTU5ODU4L3RoYW5rLXlvdQ==") });
});